# keras-cnn-handwriting-mnist
Keras - Rede Neural Convolucional para reconhecimento de dígitos escritos à mão. O código foi desenvolvido durante este vídeo: https://www.youtube.com/watch?v=FhwzOaEMk6Y
